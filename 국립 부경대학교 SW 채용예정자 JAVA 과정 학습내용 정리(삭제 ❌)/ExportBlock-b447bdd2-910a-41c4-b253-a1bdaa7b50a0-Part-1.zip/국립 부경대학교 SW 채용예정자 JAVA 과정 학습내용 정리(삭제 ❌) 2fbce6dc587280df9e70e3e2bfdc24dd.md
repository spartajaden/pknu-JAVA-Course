# 국립 부경대학교 SW 채용예정자 JAVA 과정 학습내용 정리(삭제 ❌)

[국립 부경대 SW 채용예정자 JAVA 과정 학습내용(선수학습도 포함됨)](https://www.notion.so/SW-JAVA-2f0ce6dc5872800e96e5da5ae708b9c6?pvs=21) 

[국립 부경대학교 SW 채용예정자 JAVA 과정 Python 프로그램 설치](https://www.notion.so/SW-JAVA-Python-2fbce6dc58728005a391f4f88796dc97?pvs=21) 

[우분투로 Pytorch 프로그램 접속하는 방법](https://www.notion.so/Pytorch-2fbce6dc587280ac9e54f8a66ccf93ee?pvs=21) 

[Pytorch 문자 사용방법](https://www.notion.so/Pytorch-2fcce6dc587280a49207ea6f52efe5c7?pvs=21)